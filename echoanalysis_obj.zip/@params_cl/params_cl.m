
classdef params_cl
    properties
        Time
        BandWidth
        ChannelID
        ChannelMode
        FrequencyEnd
        FrequencyStart
        PulseForm
        PulseLength
        PulseLengthEff
        SampleInterval
        Slope
        TransducerDepth=0;
        TransmitPower
        Absorbtion
    end
       
end