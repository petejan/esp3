function update_tick_labels(~,~,ax,ax_type)
update_xtick_labels([],[],ax,ax_type);
update_ytick_labels([],[],ax);
end
