function apply_soundspeed(trans,c)



end