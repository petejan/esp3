function pow=db2pow_perso(db)

    pow=10.^(db/10);

end