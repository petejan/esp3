classdef mbs_input_cl
    properties
        snapshot=[];
        stratum={};
        transect=[];
        dfileDir={};
        crestDir={};
        channel=[];
        calRev={};
        botRev={};
        regRev={};
        rawFileName={};
        rawSubDir={};
        algo={};
        calCrest=[];
        calRaw={};
        absorbtion=[];
        length=[];
        reg={};
        reg_str={};
        transducer={};
        dfileNum=[];
        rawDir={};
    end
    
    
    methods
    end
    
end