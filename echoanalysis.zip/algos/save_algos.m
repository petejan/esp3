function save_algos(~,~,main_figure)
update_algos(main_figure);
end