function ray_tracing_callback(~,~,main_figure) 


    
end