classdef filter_cl
    properties
        channelID
        NoOfCoefficients
        DecimationFactor
        Coefficients
    end
end