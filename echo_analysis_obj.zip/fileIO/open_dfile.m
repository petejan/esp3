function  open_dfile(hObject,PathToFile,Filename)
curr_disp=getappdata(hObject,'Curr_disp');
layers=getappdata(hObject,'Layers');
app_path=getappdata(hObject,'App_path');

idx_str=strfind(PathToFile,':');
linuxFilePath=fullfile('/data/ac1/',PathToFile(idx_str(1)+1:end));
linuxFilePath=strrep(linuxFilePath, '\', '/');

ifileInfo = get_ifile_info(PathToFile, str2double(Filename(2:end)));
RawFilename=ifileInfo.rawFileName;
voyage=RawFilename(1:7);
display(['converting bottom and bad pings for dfile ' Filename]);
[IdxBad,bot,~]= get_bottom_from_esp2(linuxFilePath,Filename,voyage);

display(['converting regions for dfile ' Filename]);
regions = get_regions_from_esp2(linuxFilePath,Filename,voyage);


[~,PathToRawFile]=find_file_recursive(PathToFile,RawFilename);

if isempty(PathToRawFile)
    warning('Could not find associated .*raw file');
    return;
end

if exist(fullfile(PathToRawFile{1},'cal_echo.csv'),'file')>0
    cal=csv2struct(fullfile(PathToRawFile{1},'cal_echo.csv'));
else
    cal=[];
end




layer_temp=open_EK60_file_stdalone(PathToRawFile{1},RawFilename,...
    'PathToMemmap',app_path.data,'Frequencies',[],'Calibration',cal);

idx_freq=find_freq_idx(layer_temp,38000);
layer_temp.Transceivers(idx_freq).setBottom(bot);
layer_temp.Transceivers(idx_freq).setIdxBad(IdxBad); %#ok<FNDSB>
layer_temp.Transceivers(idx_freq).add_region(regions);


disp('Shuffling layers');
[layers,layer]=shuffle_layers(layers,layer_temp,1,0);

idx_freq=find_freq_idx(layer,curr_disp.Freq);
curr_disp.Freq=layer.Frequencies(idx_freq);
curr_disp.setField('sv');

setappdata(hObject,'Layer',layer);
setappdata(hObject,'Layers',layers);
setappdata(hObject,'Curr_disp',curr_disp);

end