
function label_out=format_label(tick,ax_type)

switch ax_type
    case 'Time'
        str_end=' s';
    case 'Number'
        str_end='';
    case 'Distance'
        str_end=' m';
    otherwise
        str_end='';
end

label_out=cell(length(tick),1);

switch ax_type
    case 'Time' 
        label_out=mat2cell(datestr(tick,'HH:MM:SS'),ones(1,size(tick,2)),8);
    otherwise
        for i=1:length(tick)
            label_out{i}=[num2str(tick(i),'%.0f') str_end];           
        end
        
end
end