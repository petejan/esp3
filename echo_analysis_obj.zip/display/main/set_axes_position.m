function set_axes_position(main_figure)
main_menu=getappdata(main_figure,'main_menu');
axes_panel_comp=getappdata(main_figure,'Axes_panel');

state_colorbar=get(main_menu.show_colorbar,'checked');
state_xaxes=get(main_menu.show_xaxes,'checked');
state_yaxes=get(main_menu.show_yaxes,'checked');
pos=[0 0 1 1];

switch state_colorbar
    case 'on'
        if isfield(axes_panel_comp,'colorbar')
            set(axes_panel_comp.colorbar,'visible','on');
            pos_colorbar=get(axes_panel_comp.colorbar,'Position');
        else
            pos_colorbar=[1 0 0 0];
        end
        
    case 'off'
        if isfield(axes_panel_comp,'colorbar')
            set(axes_panel_comp.colorbar,'visible','off');
        end
        pos_colorbar=[1 0 0 0];
end

pos=pos-[0 0 1-pos_colorbar(1) 0];

inset=get(axes_panel_comp.main_axes,'TightInset'); 

 switch state_xaxes
     case 'off'
         
     case 'on'
         pos=pos+[inset(1) 0 -inset(1) 0];

 end

switch state_yaxes
    case 'off'
        
    case 'on'
        pos=pos+[0 0 0 -inset(4)];
end

         set(axes_panel_comp.main_axes,'Position',pos);
end